KOLTUK YIKAMA HESAPLAYICI - ANDROID PROJESİ

Bu klasör Android Studio ile APK üretmek için hazırlanmıştır.
Uygulama HTML hesaplayıcıyı cihaz içinde WebView ile açar. İnternet izni istemez.

APK oluşturma:
1. Bilgisayara Android Studio kur: https://developer.android.com/studio
2. ZIP dosyasını klasöre çıkart.
3. Android Studio > Open > KoltukYikama klasörünü seç.
4. Gradle senkronizasyonunun ve gerekli Android SDK 35 kurulumunun bitmesini bekle.
5. Menüden Build > Build Bundle(s) / APK(s) > Build APK(s) seç.
6. İşlem bitince çıkan "locate" bağlantısına tıkla.
7. APK genellikle app/build/outputs/apk/debug/app-debug.apk konumunda olur.
8. APK'yı Android telefona gönderip aç. Gerekirse Android, bu kaynaktan uygulama yükleme izni ister.

Not:
- Bu proje tek başına APK değildir; Android Studio ile derlenmesi gerekir.
- Uygulama çevrimdışı çalışır.
- Hesaplayıcı ayarları ve adetler cihazın uygulama verisinde saklanır.
- Yayınlanacak imzalı sürüm için ayrıca release signing gerekir.
